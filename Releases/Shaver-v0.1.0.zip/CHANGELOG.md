# Shaver — changelog

Dick The Butcher Effects. The manual (`Documentation\USER_MANUAL.md`) has the details.

## 0.1.0 — first release

- Additive synthesizer: up to 512 partials per oscillator (QUALITY LOW / MED / HIGH / ULTRA), up to
  16 voices, unison 1–4.
- Two oscillators with seven types: Pulse-Saw, Pulse Width, Sync, Formant, Bell, Organ and Random.
  Each type is morphed by SHAPE and has RATIO and COLOUR; OSC 2 also has SEMI and FINE.
- XFADE between the oscillators, driven by an LFO, Env 3, the sidechain or the mod wheel, at constant
  power.
- Two spectral filters (Lowpass, Highpass, Bandpass, Notch, Comb Peak, Comb Notch, Formant, Phaser)
  with BOOST, WIDTH, SLOPE up to 96 dB/oct and KEY TRACK, routed serial or parallel.
- Spectral FX: Clipper, Beat and Stereo Spread.
- Output section: Spectral Clip, Safe Bass, and the LMT drive, dirt and limiter stage. The dirt stage
  is 4× oversampled; the limiter peaks at −0.3 dBFS.
- Three envelopes, two LFOs (tempo sync, per-note or free) and an 8-slot mod matrix.
- Sidechain: a follower for ducking, gating and cutoff, plus retrigger on hits. It takes the host
  sidechain input, or a tempo-locked sample loop loaded into Shaver. Loops up to 30 s are saved
  inside the project.
- Presets: a factory bank of 16 and your own in
  `Documents\Dick The Butcher Effects\Shaver\Presets`. Presets never change QUALITY, VOICES, BEND or
  the sidechain section.
- Resizable window, 75–150 %.
