# Shaver v0.1.0

## Installation

### Windows
1. Run `Shaver-0.1.0-Setup.exe` and follow the prompts. If Windows says "Windows protected your PC", click **More info**, then **Run anyway** (the installer is not code-signed). If Windows blocks it with no **Run anyway** button, Smart App Control is on: use the manual install below instead.
2. The VST3 plug-in goes to `C:\Program Files\Common Files\VST3\`; the standalone app, the manual and the uninstaller go under `C:\Program Files\`, with Start menu shortcuts.
3. Rescan plug-ins in your DAW.

To remove it: Settings > Apps > Installed apps > Shaver > Uninstall.

Upgrading: when Shaver is already installed, Setup offers to back up the installed `Shaver.vst3` first, to a folder you pick (not Program Files, not `Common Files\VST3`). To go back to that version later: close your DAW, delete `C:\Program Files\Common Files\VST3\Shaver.vst3`, copy the backup's `Shaver.vst3` folder into `C:\Program Files\Common Files\VST3\`, and rescan.

Without the installer: copy the whole `Windows\VST3\Shaver.vst3` folder into `C:\Program Files\Common Files\VST3\`.

Needs the Microsoft Edge WebView2 Runtime (part of Windows 11 and of most Windows 10 PCs with Edge); the installer checks and links the download.

### macOS
Not included in this package.

### Linux
Not included in this package.

## Supported Formats
- Windows: VST3, Standalone

## Documentation
See `Documentation\USER_MANUAL.md`.

## License
See LICENSE.txt for full license terms.
