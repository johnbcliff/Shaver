# Shaver 0.1.0 — User Manual

Dick The Butcher Effects

Shaver is an additive synthesizer. Every note is built from up to 512 sine waves (partials), and
everything you hear (the oscillators, the filters, the effects) works by setting the level, pitch
and stereo position of each partial. Because the sound never passes through a conventional filter or
waveshaper until the very last stage, it stays clean at any setting: no aliasing, no resonance that
blows up, and filter shapes no analogue filter can make (combs, vowels, phasers, 96 dB/oct slopes).

Shaver is a VST3 instrument and a standalone app for 64-bit Windows 10 and 11. It needs the
Microsoft Edge WebView2 Runtime, which Windows 11 already has; the installer links to it if it is
missing.

---

## Quick start

1. Load Shaver on an instrument track and play. The Init preset is one saw through a lowpass.
2. Click the preset name at the top for the factory bank. ◀ ▶ step through it.
3. Turn OSC 1's **SHAPE**, then change its **TYPE**. SHAPE morphs every type differently (see
   Oscillators).
4. Turn FILTER 1's **CUTOFF**, then try **TYPE** = Comb Peak or Formant.
5. The mod wheel does something useful on most factory presets; each preset's note says what.

Hover any control for half a second: the tooltip gives its full name, value and what it does.

**Working the controls**

- Knobs: drag up and down (Shift for fine moves), or use the mouse wheel. Double-click resets to the
  default. Ctrl-click types a value.
- Values show while you hover or drag a knob. Steppers, switches and the mod matrix always show
  theirs.
- **SIZE** (top right) scales the window: 75, 100, 125 or 150 %. It is saved with the project.
- Every control is a host parameter, so all of it can be automated.

---

## The panel

| Area | What it holds |
|---|---|
| Header | Preset bar, QUALITY, SIZE, OUTPUT |
| VOICING (left) | Poly / mono, voices, bend range, pitch, glide, unison, phase |
| PARTIALS (top strip) | The newest note's partials, OSC 1 and OSC 2, with the filter curve over them |
| OSC 1, OSC 2 | The two oscillators |
| XFADE | What moves the mix between OSC 1 and OSC 2 |
| FILTER 1, FILTER 2 | The two spectral filters and their routing |
| SPECTRAL FX | Clipper, Beat, Spread |
| OUTPUT | Spectral Clip, Safe Bass, LMT |
| Bottom tabs | ENVELOPES & LFOS, or MOD MATRIX |
| SIDECHAIN | Follower, ducking, retrigger, and the sample loop |

A knob that is being modulated (by the matrix, Env 2, or the sidechain) shows a coloured ring from
its set value to where the newest note has it right now.

---

## Header

- **Preset bar:** see Presets.
- **QUALITY:** the most partials one oscillator may use: LOW 64, MED 128, HIGH 256, ULTRA 512.
  Partials above about 20 kHz are never made, so high notes use far fewer anyway. The difference
  shows on low notes: ULTRA is brighter in the bass and costs more CPU. HIGH is the default.
- **OUTPUT:** final level, after the limiter, −36 to +6 dB.

---

## Voicing

- **MODE:** POLY plays chords. MONO plays one note at a time. LEGATO is mono, and notes that overlap
  glide on without restarting the envelopes.
- **VOICES:** the most notes sounding at once, 1–16. The oldest note is stolen, without a click.
- **BEND:** pitch-bend range, 0–24 semitones.
- **PITCH / FINE:** transposes the whole synth (±24 semitones / ±100 cents).
- **GLIDE:** the time to slide from one note to the next. With **AUTO** on, it glides only between
  overlapping notes.
- **UNISON / DETUNE:** 1–4 copies of every note, spread in pitch by DETUNE (0–50 cents) and panned
  across the stereo field. Small DETUNE values (a few cents or less) thicken without audible chorus.
- **PHASE / RANDOM:** the start phase of every partial at note-on. RANDOM gives each partial a
  different random start, per note. With RANDOM at 0, every note starts identically, which makes
  plucks punchier and more consistent.

---

## Oscillators

OSC 1 is on by default and OSC 2 is off. Each has:

- **TYPE** and **SHAPE:** the recipe, and how SHAPE morphs it:

| TYPE | SHAPE from 0 to 100 |
|---|---|
| Pulse-Saw | Square (odd harmonics) → saw (all harmonics) |
| Pulse Width | Pulse width 50 % (square) → a very narrow pulse (thin and nasal) |
| Sync | A saw with a resonant peak that sweeps up from the 1st to the 16th harmonic: the "hard sync" scream, without a second oscillator |
| Formant | A saw through vowel formants, A → E → I → O → U. The formants stay put as you play up and down, like a voice |
| Bell | Partials stretched apart, from in tune (0) to clangorous and bell-like (100). The only type whose partials are not whole multiples |
| Organ | Five drawbar registrations: a pure sine (flute 8'), 16'+8', 888, 88-8-6, all nine bars |
| Random | A saw (0) → a saw whose partial levels are randomised on every note (100) |

- **LEVEL:** the oscillator's level, 0–100 %.
- **COLOUR:** tilts the spectrum, darker to the left and brighter to the right, up to ±6 dB per
  octave.
- **RATIO:** plays the oscillator at a whole multiple of the note, ×1 to ×24. ×2 is an octave up, ×3
  an octave and a fifth.
- **SEMI / FINE** (OSC 2 only): tunes OSC 2 against OSC 1, ±24 semitones and ±100 cents.

The two oscillators are separate sets of partials. Detune OSC 2 slightly (FINE a few cents) for
beating between them.

---

## XFade

Without XFADE, the two LEVEL knobs set the mix. XFADE lets something move that mix:

- **SOURCE:** OFF, LFO 1, LFO 2, ENV 3, SC FOLLOWER or MOD WHEEL.
- **DEPTH:** 0 % keeps the LEVEL mix. 100 % lets the source swing all the way to OSC 1 or all the way
  to OSC 2. The crossfade keeps the power constant, so the volume does not dip in the middle.
- **SMOOTH:** glides between positions, 0–1000 ms, so a stepped source (sample & hold) slides
  instead of jumping.

The meter shows the mix: a tick for the LEVEL mix and a moving marker for where the newest note is.

---

## Filters

Shaver's filters are spectral: each one is a curve that sets the level of every partial at its own
frequency. They are stateless, so they cannot ring, self-oscillate or blow up, and any change is
instant.

Filter 1 is on (Lowpass) and Filter 2 is off (Comb Peak) by default.

- **TYPE:**

| TYPE | What it does |
|---|---|
| Lowpass / Highpass | Flat, then falling away past CUTOFF at SLOPE |
| Bandpass | Passes a band around CUTOFF (WIDTH sets how wide), falling away at SLOPE on both sides |
| Notch | A deep cut at CUTOFF; WIDTH sets how wide |
| Comb Peak | Peaks every CUTOFF Hz across the spectrum, with the gaps cut; WIDTH sharpens the peaks, BOOST raises them |
| Comb Notch | Cuts every CUTOFF Hz; BOOST makes the cuts deeper |
| Formant | A vowel shape (WIDTH picks the vowel, A → U), moved up or down by CUTOFF (1 kHz = the natural vowel). BOOST raises the whole curve |
| Phaser | Four notches at CUTOFF × 1, 3, 5, 7; WIDTH stretches them apart |

- **CUTOFF:** 20 Hz–20 kHz.
- **BOOST:** a resonant bump at the cutoff, 0–24 dB.
- **WIDTH:** bandwidth, comb sharpness, the vowel, or the phaser stretch, depending on TYPE.
- **SLOPE:** 6–96 dB per octave. Only the lowpass, highpass and bandpass types use it; for the
  others it dims.
- **KEY TRACK:** moves CUTOFF with the note, 0–100 %. At 100 % the filter follows the keyboard
  exactly, so a comb lines up with the same harmonics on every note.
- **ROUTING** (on Filter 2): SERIAL runs Filter 1 then Filter 2. PARALLEL averages the two curves.

Env 2's **TO CUTOFF** (on the Envelopes tab) and SIDECHAIN **TO CUTOFF** move both cutoffs.

---

## Spectral FX

These work on the partials too, so none of them adds aliasing. Each has an on/off switch.

- **CLIPPER:** squashes the partial levels, so weak partials rise toward the strong ones: brighter,
  denser, buzzier. **DRIVE** sets how hard; **TILT** moves where in the spectrum it bites hardest
  (left = low partials, right = high).
- **BEAT:** makes neighbouring partials beat against each other, like slightly detuned pairs:
  shimmer and movement on a held note. **AMOUNT** sets how fast and deep; **PARTIAL** picks which
  partials beat, from low to high.
- **SPREAD:** pans the partials across the stereo field, alternating left and right through the
  spectrum, and moves them. **AMOUNT** is how wide; **RAMP** spreads the upper partials wider than the
  lower ones; **RATE** is how fast the pattern moves (0–10 Hz); **CYCLES** is how many left-right
  alternations run across the spectrum. Spread sums cleanly to mono.

---

## Output

- **SPECTRAL CLIP** (on by default): a ceiling on the level of every partial, which keeps bright
  sounds from turning shrill.
  - **CLIP:** how hard it clips. Higher lowers the ceiling (0 % = no clipping, 100 % = −36 dB).
  - **PITCH CUT:** lowers the ceiling for high notes, up to 12 dB at the top of the keyboard.
  - **SLOPE:** lowers the ceiling toward high frequencies.
- **SAFE BASS** (on by default): keeps the partials below about 150 Hz in the centre and starts
  them in phase on every note, so the low end hits at the same level every time and stays mono. With
  unison, it also takes the detune out of the bass.
  - **AMOUNT:** from off to fully applied.
  - **LEVEL:** the level of those low partials, −24 to +6 dB.
  - **SLOPE:** how gradually it hands over to the partials above.
- **LMT** (on by default): the only stage that works on the waveform.
  - **DRIVE:** gain into it, 0–24 dB.
  - **DIRT:** adds grit before the limiter. This stage runs at four times the sample rate, so it
    stays clean at the top.
  - A peak limiter at −0.3 dBFS follows. It stays on even with LMT switched off, so Shaver never
    clips your output.

---

## Envelopes & LFOs (bottom tab)

There are three envelopes, each with **ATTACK, DECAY, SUSTAIN, RELEASE** and **VELOCITY** (how much
playing harder raises the envelope's peak). They have analogue-style curved segments.

- **AMP ENV:** the volume of every note.
- **ENV 2 · FILTER:** moves both filter cutoffs by **TO CUTOFF** (±100 % = ±8 octaves). It is also a
  mod matrix source.
- **ENV 3:** free. Use it in the mod matrix or as the XFADE source.

There are two LFOs:

- **SHAPE:** Sine, Triangle, Saw Up, Saw Down, Square, Sample & Hold, or Smooth Random.
- **RATE:** 0.01–50 Hz. Turn **SYNC** on to lock it to the host tempo and set **DIVISION** instead
  (4/1 to 1/32, including dotted and triplet).
- **PHASE:** where in its cycle the LFO starts.
- **RETRIG:** NOTE gives every note its own LFO, starting at PHASE. FREE runs one LFO for all notes.

The LFOs do nothing until you use them in the mod matrix or as the XFADE source. Each title dot
pulses with its LFO.

---

## Mod matrix (bottom tab)

There are eight slots, each with a **SOURCE**, a **DESTINATION** and an **AMOUNT** (±100 %). The tab
title counts the slots in use.

**Sources:** LFO 1, LFO 2, Amp Env, Env 2, Env 3, Velocity, Mod Wheel, Aftertouch (channel pressure),
Key (0 at middle C, ±1 five octaves away), SC Follower (the sidechain level), and Note Random (a new
random value on every note).

**Destinations:** OSC 1 Shape, Level, Colour; OSC 2 Shape, Level, Colour, Fine; XFade Depth;
F1 Cutoff, Boost, Width; F2 Cutoff, Boost, Width; Beat Amount; Spread Amount; Clipper Drive; Pitch;
Amp; LFO 1 Rate; LFO 2 Rate.

How far 100 % goes:

| Destination | 100 % means |
|---|---|
| Cutoffs | ±4 octaves |
| Pitch | ±12 semitones |
| Amp | ×0 to ×2 |
| Everything else | the full range of the knob |

Several slots can share a destination; their amounts add up.

---

## Sidechain

The sidechain lets another sound (a kick, a drum loop) push Shaver around: duck it, open its filter,
or re-strike its notes in time.

**Where the sidechain signal comes from: SOURCE**

- **HOST:** Shaver's sidechain input, in hosts that give an instrument one.
- **SAMPLE:** a loop loaded into Shaver itself (below).
- **AUTO** (default): the sample if one is loaded, otherwise the host input.

Not every host offers a sidechain input on a VST3 instrument. FL Studio 2026 does not, so in FL use
the sample loop.

**The sample loop**

- Drop a WAV, AIFF or FLAC file on the load area, or click it to browse. The file name shows there;
  × clears it.
- The loop plays locked to the host tempo and position. It is silent: it only drives the sidechain.
  **MONITOR** mixes it into the output so you can hear it (−60 dB = off).
- **BEATS:** the loop length in beats. AUTO picks the nearest power of two to the file's length.
  The file plays at its own speed (it is not stretched): a gap is silence, and anything longer than
  the loop is cut.
- **START:** shifts the loop later against the bar.
- Files up to 30 s are saved inside the project, so the project opens anywhere. A longer file must be
  browsed for (not dropped). The project then stores only its location, and shows MISSING if the
  file has moved.

**FOLLOWER:** turns the sidechain into a smooth level. The meter and LED at the top of the panel show
it.

- **GAIN:** level into the follower and trigger, ±24 dB.
- **ATTACK / RELEASE:** how fast the follower rises and falls.
- **TO AMP:** negative ducks Shaver when the sidechain plays (pumping). Positive lets Shaver through
  only while the sidechain plays (gating). With no sidechain connected, positive values are ignored,
  so the synth never goes silent for lack of a signal.
- **TO CUTOFF:** moves both filter cutoffs with the sidechain level (±4 octaves).

**TRIGGER:** turns sidechain hits into note re-strikes.

- **RETRIGGER:** OFF, AMP, FILTER or BOTH. Each hit restarts the chosen envelopes on the notes you
  are holding.
- **THRESHOLD:** the level that counts as a hit.
- **HOLD:** the shortest time between hits.

THRESHOLD and HOLD dim while RETRIGGER is OFF.

---

## Presets

- **◀ ▶** step through the presets. A `*` after the name means you have changed something since
  loading it.
- **SAVE** saves your changes. If the preset is a factory one, it asks for a new name first.
- Click the **name** for the list: the factory bank, then your own. The menu also has Save As,
  Rename, Delete and Show folder.
- Your presets are small `.shaverpreset` files in
  `Documents\Dick The Butcher Effects\Shaver\Presets`. They can be copied and shared, and the list
  re-reads the folder every time it opens.
- The project remembers which preset it was last set to.

**What a preset leaves alone:** QUALITY, VOICES, BEND, and the whole SIDECHAIN section, including
the loaded sample. Your machine setup and the routing of your song stay as you set them while you
browse.

**Factory bank**

| Preset | What it is, and what to try |
|---|---|
| Init | One saw through the lowpass: the starting point |
| Edge Bass | Mono legato bass; the mod wheel opens the filter |
| Glass Bells | Stretched bell partials; play harder for a brighter strike |
| Vowel Choir | Two vowels crossfaded by a slow LFO through a resonant formant filter; the mod wheel moves OSC 1's vowel |
| Comb Lead | A key-tracked comb peak drifting under a saw; the mod wheel deepens it |
| Phaser Strings | Detuned pulse and saw through a slow spectral phaser |
| Sync Scream | Two sync oscillators whose peak sweeps on every note; the mod wheel pushes it higher |
| Drawbar Organ | Two sets of full drawbars, the second a little brighter, with a little beating; the mod wheel adds more |
| Shimmer Pad | A dark saw and a bell an octave up, beating and spreading across the stereo field |
| Pump Chords | For ducking under a kick: set SIDECHAIN TO AMP to about −80 % |
| Trigger Pluck | Made for SIDECHAIN RETRIGGER BOTH: the sidechain's hits re-strike the notes |
| Grit Bass | Random partials per note through a driven, dirty output |
| Wobble | A 1/8 tempo-synced filter wobble; the mod wheel adds boost |
| Drifting Notch | A notch wandering on a smooth random LFO over a slow pad |
| Hollow Flute | A sine and a quiet square an octave up, with gentle vibrato |
| Dirty Saw Lead | Four detuned saws, clipped and driven; aftertouch adds clipper drive |

---

## CPU

Shaver's cost depends on how many partials are sounding: voices × unison × oscillators × QUALITY.
Measured on the build machine at 48 kHz with 64-sample buffers, as a share of one CPU core:

| Load | CPU |
|---|---|
| 8 notes, HIGH, both oscillators | about 14 % |
| The same with Clipper, Beat and Spread all moving | about 17 % |
| 16 notes, ULTRA, unison 4, everything on | about 45 % |

If a heavy patch strains your system, drop QUALITY one step, lower UNISON, or set fewer VOICES. At
extreme settings Shaver fades out the highest partials instead of overloading.

---

## Notes for this version

0.1.0 is the first release.

- The host sidechain input is untested in FL Studio, which does not offer one for VST3 instruments.
  Use the sample loop there.
- The installer is not code-signed: Windows may say "Windows protected your PC". Click **More info**,
  then **Run anyway**.
